namespace AutoCar;

public enum TripStatus
{
    Start, Done, Cancel
}
