namespace AutoCar;

public enum VehicleStatus
{
    Busy, UnderRepair, Vacant
}
