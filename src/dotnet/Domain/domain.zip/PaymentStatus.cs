namespace AutoCar;

public enum PaymentStatus
{
    Successful, Unsuccessful
}
