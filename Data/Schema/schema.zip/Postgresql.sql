...
Download the create-db script and run it: https://github.com/sutton-institute/AutoRide/blob/main/Data/Schema/Postgresql.sql

Then download the csv files and execute to add the records

The end result is a Postgresql that is ready to use to see the application working with real-looking data.
