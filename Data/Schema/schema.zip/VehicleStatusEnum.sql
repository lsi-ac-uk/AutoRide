CREATE TYPE VehicleStatus AS ENUM(
	'Busy', 'UnderRepair', 'Vacant'
);