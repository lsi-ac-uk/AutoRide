CREATE TYPE PaymentStatus AS ENUM(
	'Successful'

);