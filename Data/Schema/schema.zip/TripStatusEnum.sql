CREATE TYPE TripStatus AS ENUM(
	'Started', 'Completed', 'Canceled'
);